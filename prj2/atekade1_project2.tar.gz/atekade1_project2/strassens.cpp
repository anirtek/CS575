/* 
 * File:   Strassens.cpp
 * Author: Aniruddha Tekade
 * Bmail:  atekade1@binghamton.edu
 * 
 * Created on March 15, 2017, 10:20 PM
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <sstream>
#include <vector>
#include <istream>
#include <iomanip>

const float LOW = -5.0f, HIGH = 5.0f;
const int LEAF_SIZE = 4;

using namespace std;

/**
 * Class definition
 */
class Matrix {
public:
    int n;
    vector<vector<float>> v;

    Matrix(int size) :
    n(size),
    v(size, vector<float>(size)) {
    };
};

void subtract(Matrix& matrixA, Matrix& matrixB, Matrix& matrixC, int size) {
    int i, j;
    for (i = 0; i < size; i++) {
        for (j = 0; j < size; j++) {
            matrixC.v[i][j] = matrixA.v[i][j] - matrixB.v[i][j];
        }
    }
}

void sum(Matrix& matrixA, Matrix& matrixB, Matrix& matrixC, int size) {
    int i, j;
    for (i = 0; i < size; i++) {
        for (j = 0; j < size; j++) {
            matrixC.v[i][j] = matrixA.v[i][j] + matrixB.v[i][j];
        }
    }
}

/**
 * Standard Matrix Multiplication algorithm
 * Time Complexity = O(n^3)
 * Logic : C[i][j] += A[i][k] * B[k][j]; 
 */
void standardMultiplication(Matrix& matrixA, Matrix& matrixB, Matrix& matrixC) {
    int i, j, k = 0;
    for (i = 0; i < matrixA.v.size(); i++) {
        for (j = 0; j < matrixB.v.size(); j++) {
            for (k = 0; k < matrixA.v.size(); k++) {
                matrixC.v[i][j] += matrixA.v[i][k] * matrixA.v[k][j];
            }
        }
    }
}

/**
 * Strassen's Matrix Multiplication algorithm
 * Time Complexity is less than O(n^3)
 * Logic : C[i][j] += A[i][k] * B[k][j]; 
 */
void strassensMultiplication(Matrix& matrixA, Matrix& matrixB, Matrix& matrixC, int size) {
    if (size <= LEAF_SIZE) {
        standardMultiplication(matrixA, matrixB, matrixC);
        return;
    } else {
        int newSize = size / 2;
        Matrix a11(newSize), a12(newSize), a21(newSize), a22(newSize);
        Matrix b11(newSize), b12(newSize), b21(newSize), b22(newSize);
        Matrix c11(newSize), c12(newSize), c21(newSize), c22(newSize);

        Matrix m1(newSize), m2(newSize), m3(newSize), m4(newSize), m5(newSize), m6(newSize), m7(newSize);

        Matrix part1(newSize), part2(newSize);

        int i, j;

        /**
         * Divide the matrices into 4 sub-matrices:
         */
        for (i = 0; i < newSize; i++) {
            for (j = 0; j < newSize; j++) {
                a11.v[i][j] = matrixA.v[i][j];
                a12.v[i][j] = matrixA.v[i][j + newSize];
                a21.v[i][j] = matrixA.v[i + newSize][j];
                a22.v[i][j] = matrixA.v[i + newSize][j + newSize];

                b11.v[i][j] = matrixB.v[i][j];
                b12.v[i][j] = matrixB.v[i][j + newSize];
                b21.v[i][j] = matrixB.v[i + newSize][j];
                b22.v[i][j] = matrixB.v[i + newSize][j + newSize];
            }
        }

        /** 
         * Calculating m1 to m7
         */

        sum(a11, a22, part1, newSize); 
        sum(b11, b22, part2, newSize); 
        strassensMultiplication(part1, part2, m1, newSize); 

        sum(a21, a22, part1, newSize); 
        strassensMultiplication(part1, b11, m2, newSize); 

        subtract(b12, b22, part2, newSize); 
        strassensMultiplication(a11, part2, m3, newSize); 

        subtract(b21, b11, part2, newSize); 
        strassensMultiplication(a22, part2, m4, newSize); 

        sum(a11, a12, part1, newSize); 
        strassensMultiplication(part1, b22, m5, newSize);

        subtract(a21, a11, part1, newSize); 
        sum(b11, b12, part2, newSize); 
        strassensMultiplication(part1, part2, m6, newSize); 

        subtract(a12, a22, part1, newSize);
        sum(b21, b22, part2, newSize); 
        strassensMultiplication(part1, part2, m7, newSize);

    }

}


/**
 * Method that generates random float numbers on every single call 
 */
float getRandomNumber() {
    float num = LOW + (float) (((HIGH - LOW) * rand()) / (RAND_MAX + 1.0));
    return num;
}

/**
 * Method that inserts random float numbers into the matrices 
 */
void insertRandomFloats(Matrix& matrix, int size) {
    int i, j;
    for (i = 0; i < size; i++) {
        for (j = 0; j < size; j++) {
            float num = getRandomNumber();
            //cout << num << "\n";
            matrix.v[i][j] = num;
        }
    }
}

/**
 * Method that displays the matrices on the console 
 */
void displayMatrix(Matrix matrix) {
    int i, j;
    for (i = 0; i < matrix.v.size(); i++) {
        for (j = 0; j < matrix.v.size(); j++) {
            cout << setprecision(3) << matrix.v[i][j] << "\t";
        }
        cout << "\n";
    }
}

int main(int argc, char* argv[]) {
    int n = std::atoi(argv[1]);
    //cout << "\nEnter the dimension of the matrix (n) : ";
    cin.clear();
    fflush(stdin);
    //cin >> n;
    /**
     * Validata integer input size of the matrices
     */
    //    while (!cin) {
    //        cout << "\nInput Error! Please enter an integer size of matrix(nxn): ";
    //        cin.clear();
    //        cin.ignore();
    //        cin >> n;
    //    }
    Matrix matrixA(n);
    Matrix matrixB(n);
    Matrix matrixC(n);

    /**
     * Insert random numbers ranging from -5.0 to 5.0 into the matrix objects
     */
    insertRandomFloats(matrixA, n);
    insertRandomFloats(matrixB, n);

    cout << "\nPrinting Matrix A ==> \n";
    displayMatrix(matrixA);
    cout << "\nPrinting Matrix B ==> \n";
    displayMatrix(matrixB);

    standardMultiplication(matrixA, matrixB, matrixC);
    cout << "\nPrinting Matrix C after Standard Multiplication algorithm ==> \n";
    displayMatrix(matrixC);

    strassensMultiplication(matrixA, matrixB, matrixC, n);
    cout << "\nPrinting Matrix C after Strassen's Multiplication algorithm ==> \n";
    displayMatrix(matrixC);

    return 0;
}
