/* 
 * File:   Strassens.cpp
 * Author: Aniruddha Tekade
 * Bmail:  atekade1@binghamton.edu
 * 
 * Created on March 15, 2017, 10:20 PM
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <sstream>
#include <vector>
#include <istream>
#include <iomanip>

//const int currentNum = 1;
using namespace std;

/**
 * Class definition
 */
class Tromino {
public:
    int currentNum;
    int n;
    vector<vector<int>> v;

    Tromino(int size) :
    currentNum(1),
    n(size),
    v(size, vector<int>(size)) {
    };
    //void tileRec(int size, int topx, int topy);
};

void tileRec(Tromino& t, int size, int topx, int topy) {

        if (size == 2) {
            for (int i = 0; i < t.v.size(); i++) {
                for (int j = 0; j < t.v.size(); j++) {
                    if (t.v[topx + i][topy + j] == 0) {
                        t.v[topx + i][topy + j] = t.currentNum;
                    }
                }
            }
            t.currentNum++;
        } // Recursive case...
        else {
            // Find coordinates of missing hole
            int savex = topx, savey = topy;

            for (int x = topx; x < topx + t.v.size(); x++) {
                for (int y = topy; y < topy + t.v.size(); y++) {
                    if (t.v[x][y] != 0) {
                        savex = x;
                        savey = y;
                    }
                }
            }

            // Hole in upper left quadrant.		
            if (savex < topx + t.v.size() / 2 && savey < topy + t.v.size() / 2) {

                // Recursively tile upper left quadrant.
                tileRec(t, t.v.size() / 2, topx, topy);
                // Fill in middle tromino
                t.v[topx + t.v.size() / 2][topy + t.v.size() / 2 - 1] = t.currentNum;
                t.v[topx + t.v.size() / 2][topy + t.v.size() / 2] = t.currentNum;
                t.v[topx + t.v.size() / 2 - 1][topy + t.v.size() / 2] = t.currentNum;

                // Advance to the next tromino
                t.currentNum++;

                // Now we can make our three other recursive calls.
                tileRec(t, t.v.size() / 2, topx, topy + t.v.size() / 2);
                tileRec(t, t.v.size() / 2, topx + t.v.size() / 2, topy);
                tileRec(t, t.v.size() / 2, topx + t.v.size() / 2, topy + t.v.size() / 2);

            } // Hole in upper right quadrant
            else if (savex < topx + t.v.size() / 2 && savey >= topy + t.v.size() / 2) {

                // Recursively tile upper right quadrant.
                tileRec(t, t.v.size() / 2, topx, topy + t.v.size() / 2);

                // Fill in middle tromino
                t.v[topx + t.v.size() / 2][topy + t.v.size() / 2 - 1] = t.currentNum;
                t.v[topx + t.v.size() / 2][topy + t.v.size() / 2] = t.currentNum;
                t.v[topx + t.v.size() / 2 - 1][topy + t.v.size() / 2 - 1] = t.currentNum;

                // Advance to the next tromino
                t.currentNum++;

                // Now we can make our three other recursive calls.
                tileRec(t, t.v.size() / 2, topx, topy);
                tileRec(t, t.v.size() / 2, topx + t.v.size() / 2, topy);
                tileRec(t, t.v.size() / 2, topx + t.v.size() / 2, topy + t.v.size() / 2);

            } // Hole in bottom left quadrant
            else if (savex >= topx + t.v.size() / 2 && savey < topy + t.v.size() / 2) {

                // Recursively tile bottom left quadrant.
                tileRec(t, t.v.size() / 2, topx + t.v.size() / 2, topy);

                // Fill in middle tromino
                t.v[topx + t.v.size() / 2 - 1][topy + t.v.size() / 2] = t.currentNum;
                t.v[topx + t.v.size() / 2][topy + t.v.size() / 2] = t.currentNum;
                t.v[topx + t.v.size() / 2 - 1][topy + t.v.size() / 2 - 1] = t.currentNum;

                // Advance to the next tromino
                t.currentNum++;

                // Now we can make our three other recursive calls.
                tileRec(t, t.v.size() / 2, topx, topy);
                tileRec(t, t.v.size() / 2, topx, topy + t.v.size() / 2);
                tileRec(t, t.v.size() / 2, topx + t.v.size() / 2, topy + t.v.size() / 2);
            } else {

                // Recursively tile bottom right quadrant.
                tileRec(t, t.v.size() / 2, topx + t.v.size() / 2, topy + t.v.size() / 2);

                // Fill in middle tromino
                t.v[topx + t.v.size() / 2 - 1][topy + t.v.size() / 2] = t.currentNum;
                t.v[topx + t.v.size() / 2][topy + t.v.size() / 2 - 1] = t.currentNum;
                t.v[topx + t.v.size() / 2 - 1][topy + t.v.size() / 2 - 1] = t.currentNum;

                // Advance to the next tromino
                t.currentNum++;

                // Now we can make our three other recursive calls.
                tileRec(t, t.v.size() / 2, topx + t.v.size() / 2, topy);
                tileRec(t, t.v.size() / 2, topx, topy + t.v.size() / 2);
                tileRec(t, t.v.size() / 2, topx, topy);
            }

        } // end large if-else

    } // end tileRec

//void Tromino::tile(Tromino & tromino) {
//    cout << "\nI am inside the tile() function";
//    tileRec(tromino, tromino.v.size(), 0, 0);
//    cout << "\nI am getting outside tile() function";
//}

int main(int argc, char* argv[]) {
    int dime, row, col;
    cin.clear();
    cin >> dime;
    cin >> row;
    cin >> col;
    
    int actualSize = 1;
    while (actualSize < dime) {
        actualSize = actualSize * 2;
    }    
//    cout << "\nActual Dimension of the grid = " << actualSize << "\n";
    
    Tromino tromino(actualSize);
    int i, j;
    /**
     * Set the value of the hole in the tromino 
     */
    tromino.v[row][col] = -1;
    
    int size = tromino.v.size();
    
    for(i = 0; i < tromino.v.size(); i++)
    {
        for(j = 0; j < tromino.v.size(); j++)
        {
            if(tromino.v[i][j] == -1)
                cout << "X" << "\t";
            else
                cout << tromino.v[i][j] << "\t";
        }
        cout << "\n";
    }
    tileRec(tromino, size, 0, 0);
    return 0;
}
